import { createBrowserRouter, RouterProvider } from "react-router-dom";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import Dashboard from "./pages/dashboard";
import Bar from "./pages/bar";
import Form from "./pages/form";
import Line from "./pages/line";
import Pie from "./pages/pie";
import FAQ from "./pages/faq";
import Login from "./pages/login";
import Geography from "./pages/geography";
import Calendar from "./pages/calendar/calendar";
import {UserManagment} from "./components"
import NotFoundPage from "./pages/errorPage/NotFoundPage ";
import RootLayout from "./pages/Root.js";
import { logout as logoutAction } from "./services/userServices.js";


import { Navigate, useLoaderData } from "react-router-dom";
import { useAuth } from "./contexts/AuthProvider.js";

const ProtectedRoute = ({ element, allowedRoles }) => {
  const { token, role } = useAuth();
  const session = token;
  if (!session) {
    return <Navigate to="/login" replace />;
  }

  if (!allowedRoles.includes(role)) {
    return <Navigate to="/unauthorized" replace />;
  }

  return element;
};

const router = createBrowserRouter([
  {
    path: "/",
    element: <RootLayout />,
    errorElement: <NotFoundPage />,
    id: "root",
    children: [
      { index: true, element: <Dashboard /> },
      { path: "login", element: <Login /> },
      { path: "logout", action: logoutAction },

      // Role-based protected routes
      {
        path: "UserManagment",
        element: (
          <ProtectedRoute
            element={<UserManagment/>}
            allowedRoles={["Admin", "Casher"]}
          />
        ),
      },
      // Role-based protected routes
      {
        path: "paymentreport",
        element: (
          <ProtectedRoute
            element={<h1>Helo beki</h1>}
            allowedRoles={["Casher"]}
          />
        ),
      },

      // Publicly accessible routes
      { path: "form", element: <Form /> },
      { path: "bar", element: <Bar /> },
      { path: "pie", element: <Pie /> },
      { path: "line", element: <Line /> },
      { path: "faq", element: <FAQ /> },
      { path: "calendar", element: <Calendar /> },
      { path: "geography", element: <Geography /> },
      { path: "unauthorized", element: <h1>Not Allowed!!</h1> },

      // Catch-All Route
      { path: "*", element: <NotFoundPage /> },
    ],
  },
]);

const queryClient = new QueryClient();

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <RouterProvider router={router} />
    </QueryClientProvider>
  );
}

export default App;
