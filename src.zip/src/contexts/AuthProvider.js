import React, { createContext, useContext, useState, useEffect } from "react";
import api from "../utils/api";
import { jwtDecode } from "jwt-decode";
import { use } from "react";

const AuthContext = createContext(undefined);

export const useAuth = () => {
  const authContext = useContext(AuthContext);
  if (!authContext) {
    throw new Error("useAuth must be used within AuthProvider");
  }
  return authContext;
};

const AuthProvider = ({ children }) => {
  const [token, setToken] = useState(null);
  const [loading, setLoading] = useState(true);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [isFirstLogin, setIsFirstLogin] = useState(null);
  const [role, setRole] = useState("");
  const [email, setEmail] = useState("");
  const [username, setUserName] = useState("");


  // Axios interceptor to add Authorization header
  useEffect(() => {
    const interceptor = api.interceptors.request.use(
      async (config) => {
        if (!token) return config;
        config.headers["Authorization"] = `Bearer ${token}`;
        return config;
      },
      (error) => Promise.reject(error)
    );

    return () => {
      api.interceptors.request.eject(interceptor);
    };
  }, [token]);

  useEffect(() => {
    const fetchToken = async () => {
      try {
       const username =localStorage.getItem('username')
        const response = await api.get(`/Account/get-token?username=${username}`);
        setToken(response?.data);
        const decoded = await jwtDecode(response?.data);
        setUserName(decoded.name);
        setRole(
          decoded["http://schemas.microsoft.com/ws/2008/06/identity/claims/role"]
        );
      } catch (error) {
        console.log('Auth Provider>> ',error.message);
      }
    };

    fetchToken();

  }, []);
 
  // Initial token fetch
  //   useEffect(() => {
  //     const fetchToken = async () => {
  //       try {
  //         const response = await api.get('/auth/Refresh', {
  //           withCredentials: true,
  //         })
  //         setToken(response.data.accessToken)
  //         setIsFirstLogin(response.data.isFirstLogin)
  //         setRole(response.data.role)
  //         setEmail(response.data.email)
  //       } catch (error) {
  //         console.error('Error fetching initial token:', error)
  //         setToken(null)
  //       } finally {
  //         setLoading(false)
  //       }
  //     }

  //     fetchToken()
  //   }, [])

  //   const login = async (email, password) => {
  //     try {
  //       let result = {}
  //       const response = await api
  //         .post('/auth/Login', { email, password }, { withCredentials: true })
  //         .then((response) => {
  //           setToken(response?.data?.accessToken)
  //           setIsFirstLogin(response?.data?.isFirstLogin) // Store the flag here
  //           setRole(response?.data?.role)
  //           setEmail(response?.data?.email2)
  //           result = response?.data
  //         })

  //       return result
  //     } catch (error) {
  //       console.error('Login failed:', error)
  //       throw error
  //     }
  //   }

  const login = async (payload) => {
    let result = {}
    const response = await api.put("/Account/Login", {
      username: payload.username,
      password: payload.password,
    }).then((response)=>{
        setToken(response?.data?.token);
        const decoded = jwtDecode(response?.data?.token);
        setUserName(decoded.name);
        setRole(
          decoded["http://schemas.microsoft.com/ws/2008/06/identity/claims/role"]
        );
        result = response?.data
    })

    return result;
  };

  const logout = async () => {
    try {
      await api.post("/auth/Logout", { withCredentials: true });
    } catch (error) {
      console.error("Logout failed:", error);
    } finally {
      setToken(null);
    }
  };

  //   if (loading) {
  //     return <div>Loading...</div>
  //   }

  return (
    <AuthContext.Provider value={{ token, login, username, role }}>
      {children}
    </AuthContext.Provider>
  );
};

export default AuthProvider;
