import React, { useState } from "react";
import "./UserManagment.css";
import { DataGrid } from "@mui/x-data-grid";
import { IconButton, Button } from "@mui/material";
import EditIcon from "@mui/icons-material/Edit";
import DeleteIcon from "@mui/icons-material/Delete";
import PasswordIcon from "@mui/icons-material/VpnKey";
import PersonAddIcon from "@mui/icons-material/PersonAdd";
import AddUserModal from "./AddUserModal";

const UserManagment = () => {
  const columns = [
    { field: "id", headerName: "ID", flex: 1 },
    { field: "username", headerName: "UserName", flex: 1 },
    { field: "email", headerName: "Email", flex: 1 },
    { field: "phoneNumber", headerName: "PhoneNumber", flex: 1 },
    { field: "role", headerName: "Role", flex: 1 },
    {
      field: "actions",
      headerName: "Actions",
      width: 150,
      renderCell: (params) => (
        <>
          <IconButton
            // onClick={() => handleEditUser(params.row)}
            aria-label="edit"
            className="text-info"
          >
            <EditIcon />
          </IconButton>
          <IconButton
            // onClick={() => handleOpenDeleteConfirm(params.row)}
            color="danger"
            aria-label="delete"
            className="text-danger"
          >
            <DeleteIcon />
          </IconButton>
          <IconButton
            // onClick={() => handleOpenResetConfirm(params.row)}
            color="warning"
            aria-label="reset password"
            className="text-warnning"
          >
            <PasswordIcon />
          </IconButton>
        </>
      ),
    },
  ];

  const rows = [
    {
      id: 1,
      username: "test1",
      email: "user1@example.com",
      phoneNumber: "964551",
      role: "Admin",
    },
    {
      id: 2,
      username: "test2",
      email: "user1@example.com",
      phoneNumber: "964551",
      role: "Admin",
    },
    {
      id: 3,
      username: "test3",
      email: "user1@example.com",
      phoneNumber: "964551",
      role: "Admin",
    },
    {
      id: 4,
      username: "test4",
      email: "user1@example.com",
      phoneNumber: "964551",
      role: "Admin",
    },
  ];
  const [modalOpen, setModalOpen] = useState(false);

  // Handle the form submission
  const handleAddUser = (userData) => {
    console.log("New User Data:", userData);
    // Send userData to your backend API or perform other actions
  };

  return (
    <div className="user-management-container">
      <h1 className="hed">User Management</h1>

      <Button
        variant="contained"
        color="primary"
        startIcon={<PersonAddIcon />}
        onClick={() => setModalOpen(true)}
      >
        Add User
      </Button>

      <AddUserModal
        isOpen={modalOpen}
        onClose={() => setModalOpen(false)}
        onSubmit={handleAddUser}
      />

      <div className="data-grid-container">
        <DataGrid
          rows={rows}
          columns={columns}
          autoHeight
          pageSizeOptions={[5, 10]}
        />
      </div>
    </div>
  );
};

export default UserManagment;
