import React, { useState } from "react";
import {
  Modal,
  Box,
  Typography,
  TextField,
  Button,
  MenuItem,
  IconButton,
  Backdrop,
} from "@mui/material";
import CloseIcon from "@mui/icons-material/Close";

const AddUserModal = ({ isOpen, onClose, onSubmit }) => {
  const [formData, setFormData] = useState({
    username: "",
    email: "",
    password: "",
    phone: "",
    role: "",
  });

  const [usernameError, setUsernameError] = useState("");
  const [emailError, setEmailError] = useState("");
  const [phoneError, setPhoneError] = useState("");

  const roles = ["Admin", "User", "Editor", "Viewer"];

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
    if (e.target.name === "email") {
      validateEmail(e.target.value);
    }
    if (e.target.name === "phone") {
      validatePhoneNumber(e.target.value);
    }
    if (e.target.name === "username") {
      validateUsername(e.target.value);
    }
  };

  const validateUsername = (username) => {
    // Regex to check username starts with a letter, no spaces, and length > 2
    const usernameRegex = /^[A-Za-z][A-Za-z0-9]{1,}$/;
    if (!usernameRegex.test(username)) {
      setUsernameError(
        "Username must start with a letter, be at least 3 characters long, and contain no spaces."
      );
    } else {
      setUsernameError("");
    }
  };

  const validateEmail = (email) => {
    // Simple regex to validate email format
    const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zAZ0-9.-]+\.[a-zA-Z]{2,}$/;
    if (!emailRegex.test(email)) {
      setEmailError("Please enter a valid email address.");
    } else {
      setEmailError("");
    }
  };

  const validatePhoneNumber = (phone) => {
    // Regex to match phone numbers starting with +251, 09, or 07
    const phoneRegex = /^(?:\+251|09|07)\d+$/;

    if (!phoneRegex.test(phone)) {
      setPhoneError("Phone number must start with +251, 09, or 07 and contain only numbers.");
    } else {
      if (phone.startsWith("+251") && phone.length !== 13) {
        setPhoneError("Phone number starting with +251 must have 13 digits.");
      } else if ((phone.startsWith("09") || phone.startsWith("07")) && phone.length !== 10) {
        setPhoneError("Phone number starting with 09 or 07 must have 10 digits.");
      } else {
        setPhoneError("");
      }
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!usernameError && !emailError && !phoneError) {
      onSubmit(formData);
      onClose();
    } else {
      alert("Please fix the errors before submitting.");
    }
  };

  return (
    <Modal
      open={isOpen}
      onClose={(event, reason) => {
        if (reason !== "backdropClick" && reason !== "escapeKeyDown") {
          onClose();
        }
      }}
      disableEscapeKeyDown
      closeAfterTransition
      BackdropComponent={Backdrop}
      BackdropProps={{ timeout: 500 }}
    >
      <Box sx={modalStyle}>
        <Box display="flex" justifyContent="space-between" alignItems="center">
          <Typography variant="h6">Add New User</Typography>
          <IconButton onClick={onClose}>
            <CloseIcon />
          </IconButton>
        </Box>

        <form onSubmit={handleSubmit}>
          <TextField
            fullWidth
            label="Username"
            name="username"
            value={formData.username}
            onChange={handleChange}
            margin="normal"
            required
            error={!!usernameError}
            helperText={usernameError}
          />
          <TextField
            fullWidth
            label="Email"
            name="email"
            type="email"
            value={formData.email}
            onChange={handleChange}
            margin="normal"
            required
            error={!!emailError}
            helperText={emailError}
          />
          <TextField
            fullWidth
            label="Password"
            name="password"
            type="password"
            value={formData.password}
            onChange={handleChange}
            margin="normal"
            required
          />
          <TextField
            fullWidth
            label="Phone Number"
            name="phone"
            type="tel"
            value={formData.phone}
            onChange={handleChange}
            margin="normal"
            error={!!phoneError}
            helperText={phoneError}
            required
          />
          <TextField
            select
            fullWidth
            label="Role"
            name="role"
            value={formData.role}
            onChange={handleChange}
            margin="normal"
            required
          >
            {roles.map((role) => (
              <MenuItem key={role} value={role}>
                {role}
              </MenuItem>
            ))}
          </TextField>

          <Box display="flex" justifyContent="flex-end" mt={2}>
            <Button onClick={onClose} color="secondary" sx={{ mr: 2 }}>
              Close
            </Button>
            <Button type="submit" variant="contained" color="primary">
              Add User
            </Button>
          </Box>
        </form>
      </Box>
    </Modal>
  );
};

// Modal Styles
const modalStyle = {
  position: "absolute",
  top: "50%",
  left: "50%",
  transform: "translate(-50%, -50%)",
  width: 400,
  bgcolor: "background.paper",
  boxShadow: 24,
  p: 3,
  borderRadius: 2,
};

export default AddUserModal;
