import { redirect } from "react-router-dom";
import api from "../utils/api";

const tokenName = "session";

function getSessionDuration(session) {
    try {
        const payload = JSON.parse(atob(session.split(".")[1])); // Decode JWT payload
        const exp = payload.exp * 1000; // Convert to milliseconds
        return exp - Date.now(); // Remaining time
    } catch (error) {
        return -1; // Invalid token
    }
}


export async function login(user) {
    const fak = {session:'bereket'}
   const response = await api.put("/Account/Login",{username:user.username,password:user.password})
    return {...response.data};
}



export function logout() {
    localStorage.removeItem(tokenName);
    localStorage.removeItem('expiration');
    localStorage.removeItem('username');
    return redirect('/login')
}


export function getSession({ context }) {
    const tokenName = "authToken"; // Ensure token name is defined
    const session = context?.token || localStorage.getItem(tokenName); // Use context first

    if (!session) {
        return null;
    }

    const sessionDuration = getSessionDuration(session);
    if (sessionDuration < 0) {
        return null; // Return null instead of a string
    }

    return session;
}
